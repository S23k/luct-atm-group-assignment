package banking;

// Inheritance and interface implementation.
public final class SavingsAccount extends BankAccount implements Loanable
{
    private static final double MINIMUM_BALANCE = 100.00;
    private static final double LOAN_LIMIT = 5000.00;
    private static final double INTEREST_RATE = 0.05;

    public SavingsAccount(String accountNumber, String accountHolder, double balance) 
    {
        super(accountNumber, accountHolder, balance);
    }

    // Overriding: savings deposit behavior.
    @Override
    public void deposit(double amount) 
    {
        depositAmount(amount);
    }

    // Overriding: savings withdrawal behavior.
    @Override
    public void withdraw(double amount) 
    {
        withdrawAmount(amount, MINIMUM_BALANCE);
    }

    // Overriding: savings interest calculation.
    @Override
    public double calculateInterest() 
    {
        return getBalance() * INTEREST_RATE;
    }

    @Override
    public void requestLoan(double amount) 
    {
        if (!Double.isFinite(amount) || amount <= 0 || amount > LOAN_LIMIT) 
        {
            throw new IllegalArgumentException(
                    "Loan amount must be positive and cannot exceed 5000.00.");
        }
        addLoanAmount(amount);
        System.out.printf("Loan request of %.2f submitted for account %s.%n",
                amount, getAccountNumber());
    }
}
