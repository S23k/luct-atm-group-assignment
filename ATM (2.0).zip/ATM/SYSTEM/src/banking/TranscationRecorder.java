package banking;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;

public class TranscationRecorder 
{
    private static final Path FILE = Path.of("transactions.txt");

    public static void recordSystem(String type, String result) throws IOException 
    {
        try (BufferedWriter writer = Files.newBufferedWriter(
                FILE,
                StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND)) 
                {
            writer.write("Date/time: " + LocalDateTime.now()
                    + " | Account number: SYSTEM"
                    + " | Transaction: " + type
                    + " | Result/message: " + result);
            writer.newLine();
        }
    }

    public static void record(BankAccount account, String type, Double amount, String result)
            throws IOException 
            {
                try (BufferedWriter writer = Files.newBufferedWriter(
                FILE,
                StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND)) 
                {
                    writer.write("Date/time: " + LocalDateTime.now()
                    + " | Account number: " + account.getAccountNumber()
                    + " | Transaction: " + type
                    + (amount == null ? "" : " | Amount: " + amount)
                    + " | Balance: " + account.getBalance()
                    + " | Result/message: " + result);
                    writer.newLine();
                }
            }
}
