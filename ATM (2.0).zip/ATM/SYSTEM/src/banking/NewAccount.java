package banking;

public final class NewAccount 
{
    public enum Type 
    {
        SAVINGS,
        CURRENT
    }

    private NewAccount() 
    {

    }

    public static BankAccount create(Type type, String accountNumber, String accountHolder,
            double initialBalance) 
            {
        if (type == null) 
            {
                throw new IllegalArgumentException("Account type is required.");
            }
        if (accountNumber == null || accountNumber.isBlank()) 
            {
                throw new IllegalArgumentException("Account number cannot be blank.");
            }
        if (accountHolder == null || accountHolder.isBlank()) 
            {
                throw new IllegalArgumentException("Account holder name cannot be blank.");
        
            }

        return switch (type) 
        {
            case SAVINGS -> new SavingsAccount(accountNumber, accountHolder, initialBalance);
            case CURRENT -> new CurrentAccount(accountNumber, accountHolder, initialBalance);
        };
    }
}
