package banking;

// Abstraction
public abstract class BankAccount 
{
    // Encapsulation
    private final String accountNumber;
    private final String accountHolder;
    private double balance;

    public BankAccount(String accountNumber, String accountHolder, double balance) 
    {
        if (!Double.isFinite(balance) || balance < 0) 
        {
            throw new IllegalArgumentException("Initial balance must be finite and cannot be negative.");
        }
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = balance;
    }

    public String getAccountNumber() 
    {
        return accountNumber;
    }

    public String getAccountHolder() 
    {
        return accountHolder;
    }

    public double getBalance() 
    {
        return balance;
    }

    private void changeBalance(double amount, double minimumBalance) 
    {
        double updatedBalance = balance + amount;
        if (!Double.isFinite(updatedBalance))
        {
            throw new IllegalArgumentException("Account balance must remain finite.");
        }
        if (updatedBalance < minimumBalance) 
        {
            throw new IllegalStateException("Insufficient funds or minimum balance would be breached.");
        }
        balance = updatedBalance;
    }

    protected final void depositAmount(double amount)
    {
        depositAmount(amount, 0);
    }

    protected final void depositAmount(double amount, double minimumBalance)
    {
        if (!Double.isFinite(amount) || amount <= 0)
        {
            throw new IllegalArgumentException("Deposit amount must be a positive, finite number.");
        }
        changeBalance(amount, minimumBalance);
    }

    protected final void withdrawAmount(double amount)
    {
        withdrawAmount(amount, 0);
    }

    protected final void withdrawAmount(double amount, double minimumBalance)
    {
        if (!Double.isFinite(amount) || amount <= 0)
        {
            throw new IllegalArgumentException("Withdrawal amount must be a positive, finite number.");
        }
        changeBalance(-amount, minimumBalance);
    }

    protected final void addLoanAmount(double amount)
    {
        addLoanAmount(amount, 0);
    }

    protected final void addLoanAmount(double amount, double minimumBalance)
    {
        if (!Double.isFinite(amount) || amount <= 0)
        {
            throw new IllegalArgumentException("Loan amount must be a positive, finite number.");
        }
        changeBalance(amount, minimumBalance);
    }

    public void display()
    {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Holder: " + accountHolder);
        System.out.println("Balance: " + balance);
    }

    public abstract void deposit(double amount);

    public abstract void withdraw(double amount);

    public abstract double calculateInterest();
}
