package banking;

// Interface accounts that implement it can request loans.
public interface Loanable 
{
    void requestLoan(double amount);
}
