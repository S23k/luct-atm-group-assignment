package banking;

public class CurrentAccount extends BankAccount implements Loanable
{
    private static final double OVERDRAFT_LIMIT = 2000.00;
    private static final double LOAN_LIMIT = 10000.00;

    public CurrentAccount(String accountNumber, String accountHolder, double balance) 
    {
        super(accountNumber, accountHolder, balance);
    }

    // Overriding current-account deposit behavior.
    @Override
    public void deposit(double amount) 
    {
        depositAmount(amount, -OVERDRAFT_LIMIT);
    }

    // Overriding current-account withdrawal behavior
    @Override
    public void withdraw(double amount) 
    {
        withdrawAmount(amount, -OVERDRAFT_LIMIT);
    }

    // Overriding current-account interest calculation
    @Override
    public double calculateInterest() 
    {
        return 0.0;
    }

    @Override
    public void requestLoan(double amount) 
    {
        if (!Double.isFinite(amount) || amount <= 0 || amount > LOAN_LIMIT) 
        {
            throw new IllegalArgumentException(
                    "Loan amount must be positive and cannot exceed 10000.00.");
        }
        addLoanAmount(amount, -OVERDRAFT_LIMIT);
        System.out.printf("Loan request of %.2f submitted for account %s.%n", amount, getAccountNumber());
    }
}
