import banking.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class App 
{
    private static final Scanner scanner = new Scanner(System.in);
    private static final List<BankAccount> accounts = new ArrayList<>(List.of(
        new SavingsAccount("7700 4455", "Student Safe Box", 1000.00),
        new CurrentAccount("7700 1000", "boithati Qhaleli", 500.00)));
    private static boolean running = true;

    public static void main(String[] args) throws IOException 
    {
        displayWelcomeBanner();
        while (running) 
        {
            System.out.println("\n1. Display all accounts");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer");
            System.out.println("5. Calculate interest");
            System.out.println("6. Request loan");
            System.out.println("7. Display account details");
            System.out.println("8. Create new account");
            System.out.println("9. Exit");
            System.out.println("enter choice 1 to 9 : ");

            int choice = readChoice("Choose an option: ", 1, 9);
            switch (choice) 
            {
                case -1 -> 
                {
                    TranscationRecorder.recordSystem("EXIT", "Input ended; application closed safely.");
                    running = false;
                }
                case 1 -> displayAllAccounts();
                case 2 -> deposit();
                case 3 -> withdraw();
                case 4 -> transfer();
                case 5 -> calculateInterest();
                case 6 -> requestLoan();
                case 7 -> displayAccountDetails();
                case 8 -> createAccount();
                case 9 -> {
                    TranscationRecorder.recordSystem("EXIT", "Application closed safely.");
                    running = false;
                    System.out.println("\n!!BYE!!\nTHANKS FOR USING\nLUCT BANKING APP");
                }
                default -> System.out.println("Invalid menu choice. Choose 1 to 9.");
            }
        }
    }

    private static void displayWelcomeBanner() {
        System.out.println("====================================");
        System.out.println("WELCOME TO LUCT BANKING APP");
        System.out.println("====================================");
    }

    private static void displayAllAccounts() {
        for (BankAccount account : accounts) {
            account.display();
            System.out.println();
        }
    }

    private static void createAccount() throws IOException
    {
        System.out.println("1. Savings account");
        System.out.println("2. Current account");
        int choice = readChoice("Choose an account type: ", 1, 2);
        if (choice == -1) {
            closeForEndOfInput();
            return;
        }

        String accountNumber = readNewAccountNumber();
        if (accountNumber == null) {
            closeForEndOfInput();
            return;
        }

        String accountHolder = readNonBlankText("Account holder name: ");
        if (accountHolder == null) {
            closeForEndOfInput();
            return;
        }

        Double balance = readInitialBalance();
        if (balance == null) {
            closeForEndOfInput();
            return;
        }

        NewAccount.Type type = choice == 1 ? NewAccount.Type.SAVINGS : NewAccount.Type.CURRENT;
        BankAccount account = NewAccount.create(type, accountNumber, accountHolder, balance);
        TranscationRecorder.recordSystem("ACCOUNT CREATION",
                "Created " + type.name().toLowerCase() + " account "
                        + account.getAccountNumber() + " for " + account.getAccountHolder());
        accounts.add(account);
        System.out.println("Account created successfully.");
    }

    private static String readNewAccountNumber() {
        while (true) {
            System.out.print("New account number: ");
            if (!scanner.hasNextLine()) return null;
            String accountNumber = scanner.nextLine().trim();
            if (accountNumber.isEmpty()) {
                System.out.println("Account number cannot be blank.");
                continue;
            }
            boolean alreadyExists = accounts.stream()
                    .anyMatch(account -> account.getAccountNumber().equals(accountNumber));
            if (alreadyExists) {
                System.out.println("That account number is already in use.");
                continue;
            }
            return accountNumber;
        }
    }

    private static String readNonBlankText(String prompt) {
        while (true) {
            System.out.print(prompt);
            if (!scanner.hasNextLine()) return null;
            String value = scanner.nextLine().trim();
            if (!value.isEmpty()) return value;
            System.out.println("This value cannot be blank.");
        }
    }

    private static Double readInitialBalance() {
        while (true) {
            System.out.print("Initial balance: ");
            if (!scanner.hasNextLine()) return null;
            try {
                double balance = Double.parseDouble(scanner.nextLine().trim());
                if (Double.isFinite(balance) && balance >= 0) return balance;
            } catch (NumberFormatException e) {
                System.out.println("Enter a valid, non-negative amount.");
                continue;
            }
            System.out.println("Enter a valid, non-negative amount.");
        }
    }

    private static void closeForEndOfInput() throws IOException {
        TranscationRecorder.recordSystem("EXIT", "Input ended; application closed safely.");
        running = false;
    }

    private static void deposit() throws IOException 
    {
        BankAccount account = chooseAccount();
        if (account == null) return;
        Double amount = readAmount(account, "Deposit", "Deposit amount: ");
        if (amount == null) return;
        performTransaction(account, "Deposit", amount);
    }

    private static void withdraw() throws IOException 
    {
        BankAccount account = chooseAccount();
        if (account == null) return;
        Double amount = readAmount(account, "Withdrawal", "Withdrawal amount: ");
        if (amount == null) return;
        performTransaction(account, "Withdrawal", amount);
    }

    private static void transfer() throws IOException 
    {
        System.out.println("Select the account to transfer from:");
        BankAccount from = chooseAccount();
        if (from == null) return;

        System.out.println("Select the account to transfer to:");
        BankAccount to = chooseAccount();
        if (to == null) return;
        if (from == to) 
        {
            System.out.println("Choose two different accounts for a transfer.");
            TranscationRecorder.record(from, "Transfer", null,
                    "Rejected: source and destination accounts must differ.");
            return;
        }

        Double amount = readAmount(from, "Transfer", "Transfer amount: ");
        if (amount == null) return;
        try 
        {
            if (!Double.isFinite(amount) || amount <= 0) 
            {
                throw new IllegalArgumentException("Transfer amount must be positive.");
            }
            if (!Double.isFinite(to.getBalance() + amount)) 
            {
                throw new IllegalArgumentException("Destination balance must remain finite.");
            }
            from.withdraw(amount);
            to.deposit(amount);
            TranscationRecorder.record(from, "Transfer sent to " + to.getAccountNumber(),
                    amount, "Successful");
            TranscationRecorder.record(to, "Transfer received from " + from.getAccountNumber(),
                    amount, "Successful");
            System.out.println("Transfer successful.");
        } 
        catch (IllegalArgumentException | IllegalStateException e) 
        {
            TranscationRecorder.record(from, "Transfer", amount, e.getMessage());
            System.out.println("Transfer failed: " + e.getMessage());
        }
    }

    private static void calculateInterest() throws IOException 
    {
        BankAccount account = chooseAccount();
        if (account == null) return;
        double interest = account.calculateInterest();
        System.out.printf("Interest: %.2f%n", interest);
        TranscationRecorder.record(account, "Interest calculation", interest, "Calculated");
    }

    private static void requestLoan() throws IOException 
    {
        BankAccount account = chooseAccount();
        if (account == null) return;
        Double amount = readAmount(account, "Loan request", "Loan amount: ");
        if (amount == null) return;
        performTransaction(account, "Loan request", amount);
    }

    private static void displayAccountDetails() 
    {
        BankAccount account = chooseAccount();
        if (account != null) account.display();
    }

    private static BankAccount chooseAccount() 
    {
        for (int i = 0; i < accounts.size(); i++) {
            BankAccount account = accounts.get(i);
            System.out.printf("%d. %s (%s) - %s%n", i + 1,
                    account instanceof SavingsAccount ? "Savings" : "Current",
                    account.getAccountNumber(), account.getAccountHolder());
        }
        int choice = readChoice("Choose an option: ", 1, accounts.size());
        if (choice == -1) return null;
        return accounts.get(choice - 1);
    }

    private static void performTransaction(BankAccount account, String type, double amount)throws IOException 
    {
        // Polymorphism: the selected account's override handles the call.
        try 
        {
            switch (type) 
            {
                case "Deposit" -> account.deposit(amount);
                case "Withdrawal" -> account.withdraw(amount);
                case "Loan request" -> ((Loanable) account).requestLoan(amount);
                default -> throw new IllegalArgumentException("Unknown transaction type.");
            }
            TranscationRecorder.record(account, type, amount, "Successful");
            System.out.println(type + " successful.");
        // Exception handling: report invalid or failed transactions.
        } catch (IllegalArgumentException | IllegalStateException e) 
        {
            TranscationRecorder.record(account, type, amount, e.getMessage());
            System.out.println(type + " failed: " + e.getMessage());
        }
    }

    private static int readChoice(String prompt, int minimum, int maximum) 
    {
        while (true) {
            System.out.print(prompt);
            if (!scanner.hasNextLine()) return -1;
            try 
            {
                int choice = Integer.parseInt(scanner.nextLine().trim());
                if (choice >= minimum && choice <= maximum) return choice;
            } 
            catch (NumberFormatException e) 
            {
                // Show the same prompt for invalid numeric input.
            }
            System.out.printf("Enter a number from %d to %d.%n", minimum, maximum);
        }
    }

    private static Double readAmount(BankAccount account, String type, String prompt)
            throws IOException {
        while (true) {
            System.out.print(prompt);
            if (!scanner.hasNextLine()) {
                TranscationRecorder.record(account, type, null,
                        "Rejected: input ended before a valid amount was entered.");
                running = false;
                return null;
            }
            try 
            {
                double amount = Double.parseDouble(scanner.nextLine().trim());
                if (Double.isFinite(amount)) return amount;
            } catch (NumberFormatException e) 
            {
                TranscationRecorder.record(account, type, null,
                        "Rejected: amount must be a valid finite number.");
                System.out.println("Enter a valid number.");
                continue;
            }
            TranscationRecorder.record(account, type, null,
                    "Rejected: amount must be a valid finite number.");
            System.out.println("Enter a valid number.");
        }
    }
}
